USE AdventureWorks2016CTP3
GO
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Sales].[SalesOrderDetail2]') AND type in (N'U'))
--DROP TABLE [Sales].[SalesOrderDetail2]
--GO
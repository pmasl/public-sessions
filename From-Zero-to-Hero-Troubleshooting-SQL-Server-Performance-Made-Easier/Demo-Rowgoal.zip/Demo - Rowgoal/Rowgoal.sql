-- Check SSMS option "Actual Execution Plan"

USE AdventureWorks2016CTP3
GO

------------------------------------------------------------------------------------------
-- Demo 1 "Bad" row goal 
------------------------------------------------------------------------------------------

DBCC DROPCLEANBUFFERS
GO
-- Will select nested loop
SELECT TOP 250 *
FROM Production.TransactionHistory H
INNER JOIN Production.Product P ON  H.ProductID = P.ProductID
OPTION (RECOMPILE)
GO

DBCC DROPCLEANBUFFERS
GO
-- Will select hash join when row goal is disabled
SELECT TOP 250 *
FROM Production.TransactionHistory H
INNER JOIN Production.Product P ON  H.ProductID = P.ProductID
OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
GO


-- Row goal is applied when fast option is used
DBCC DROPCLEANBUFFERS
GO
-- Will select nested loop
SELECT *
FROM Production.TransactionHistory H
INNER JOIN Production.Product P ON  H.ProductID = P.ProductID
OPTION (RECOMPILE, FAST 250)
GO

DBCC DROPCLEANBUFFERS
GO
-- Will select hash join when row goal is disabled
SELECT *
FROM Production.TransactionHistory H
INNER JOIN Production.Product P ON  H.ProductID = P.ProductID
OPTION (RECOMPILE, FAST 250, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
GO


------------------------------------------------------------------------------------------
-- Demo 2 "Good" row goal
------------------------------------------------------------------------------------------

USE [AdventureWorks2016CTP3];  
GO  

-- Notice how Rowgoal operates as expected between 1st and 2nd
DBCC DROPCLEANBUFFERS
GO
SELECT TOP (100) *
FROM Sales.SalesOrderHeaderBulk AS s 
	INNER JOIN Sales.SalesOrderDetailBulk AS d ON s.SalesOrderID = d.SalesOrderID
WHERE s.TotalDue > 1000
OPTION (RECOMPILE);
GO

DBCC DROPCLEANBUFFERS
GO
SELECT TOP (100) *
FROM Sales.SalesOrderHeaderBulk AS s 
	INNER JOIN Sales.SalesOrderDetailBulk AS d ON s.SalesOrderID = d.SalesOrderID
WHERE s.TotalDue > 1000
OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'));
GO


------------------------------------------------------------------------------------------
-- Demo 3 "Bad" row goal 
------------------------------------------------------------------------------------------

DBCC DROPCLEANBUFFERS
GO
-- Will select merge join
SELECT TOP 1500 h.SalesOrderID, h.RevisionNumber, h.OrderDate, h.DueDate, h.ShipDate, h.Status, h.OnlineOrderFlag, h.PurchaseOrderNumber, h.AccountNumber, h.CustomerID, h.SalesPersonID, h.TerritoryID, h.BillToAddressID, 
    h.ShipToAddressID, h.ShipMethodID, h.CreditCardID, h.CreditCardApprovalCode, h.CurrencyRateID, h.SubTotal, h.TaxAmt, h.Freight, h.Comment, h.rowguid, h.ModifiedDate, d.SalesOrderID AS SalesOrderID, 
	d.SalesOrderDetailID, d.CarrierTrackingNumber, d.OrderQty, d.ProductID, d.SpecialOfferID, d.UnitPrice, d.UnitPriceDiscount, d.rowguid AS rowguid, d.ModifiedDate AS ModifiedDate
FROM Sales.SalesOrderHeader AS h 
INNER JOIN Sales.SalesOrderDetail AS d ON h.SalesOrderID = d.SalesOrderID
WHERE (h.OrderDate >= '2014-4-28 00:00:00')
OPTION (RECOMPILE)
GO

DBCC DROPCLEANBUFFERS
GO
-- Will select hash join when row goal is disabled
SELECT TOP 1500 h.SalesOrderID, h.RevisionNumber, h.OrderDate, h.DueDate, h.ShipDate, h.Status, h.OnlineOrderFlag, h.PurchaseOrderNumber, h.AccountNumber, h.CustomerID, h.SalesPersonID, h.TerritoryID, h.BillToAddressID, 
    h.ShipToAddressID, h.ShipMethodID, h.CreditCardID, h.CreditCardApprovalCode, h.CurrencyRateID, h.SubTotal, h.TaxAmt, h.Freight, h.Comment, h.rowguid, h.ModifiedDate, d.SalesOrderID AS SalesOrderID, 
	d.SalesOrderDetailID, d.CarrierTrackingNumber, d.OrderQty, d.ProductID, d.SpecialOfferID, d.UnitPrice, d.UnitPriceDiscount, d.rowguid AS rowguid, d.ModifiedDate AS ModifiedDate
FROM Sales.SalesOrderHeader AS h 
INNER JOIN Sales.SalesOrderDetail AS d ON h.SalesOrderID = d.SalesOrderID
WHERE (h.OrderDate >= '2014-4-28 00:00:00')
OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
GO

------------------------------------------------------------------------------------------
-- Demo 4 "Bad" row goal 
------------------------------------------------------------------------------------------

DBCC DROPCLEANBUFFERS
GO
-- Will select merge join
SELECT TOP 1500 h.[SalesOrderID]
FROM Sales.SalesOrderHeader AS h 
INNER JOIN Sales.SalesOrderDetail AS d ON h.SalesOrderID = d.SalesOrderID 
WHERE (h.OrderDate >= '2014-3-28 00:00:00')
OPTION (RECOMPILE)
GO

DBCC DROPCLEANBUFFERS
GO
-- Will select hash join when row goal is disabled
SELECT TOP 1500 h.[SalesOrderID] 
FROM Sales.SalesOrderHeader AS h 
INNER JOIN Sales.SalesOrderDetail AS d ON h.SalesOrderID = d.SalesOrderID
WHERE (h.OrderDate >= '2014-3-28 00:00:00')
OPTION (RECOMPILE, USE HINT('DISABLE_OPTIMIZER_ROWGOAL'))
GO


DBCC DROPCLEANBUFFERS
GO
-- Will select hash join if we force index, but look at grants and elapsed time still
SELECT TOP 1500 h.[SalesOrderID]
FROM Sales.SalesOrderHeader AS h 
INNER JOIN Sales.SalesOrderDetail AS d WITH(INDEX(IX_SalesOrderDetail_ProductID)) ON h.SalesOrderID = d.SalesOrderID 
WHERE (h.OrderDate >= '2014-3-28 00:00:00')
OPTION (RECOMPILE)
GO


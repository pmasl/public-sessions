USE [AdventureWorks2016CTP3]
GO

IF OBJECT_ID(N'[dbo].ProductCostDifference', N'FN') IS NOT NULL 
    DROP FUNCTION Production.ProductCostDifference;
GO
 
CREATE FUNCTION dbo.ProductCostDifference
    (
      @ProductId INT ,
      @StartDate DATETIME ,
      @EndDate DATETIME 
    )
RETURNS MONEY
AS 
    BEGIN
        DECLARE @StartingCost AS MONEY;
        DECLARE @CostDifference AS MONEY;
 
        SELECT TOP 1
                @StartingCost = pch.StandardCost
        FROM    Production.ProductCostHistory AS pch
        WHERE   pch.ProductID = @ProductId
                AND EndDate BETWEEN @StartDate
                                AND @EndDate
        ORDER BY StartDate ASC;
 
        SELECT TOP 1
                @CostDifference = StandardCost - @StartingCost
        FROM    Production.ProductCostHistory AS pch
        WHERE   pch.ProductID = @ProductId
                AND EndDate BETWEEN @StartDate
                                AND @EndDate
        ORDER BY StartDate DESC; 
 
        RETURN  @CostDifference;
    END
GO

--simple query
SELECT dbo.ProductCostDifference(707, '1999-01-01', GETDATE());
GO

--QUERY 1
SELECT ProductID, [Name] AS ProductName, 
	dbo.ProductCostDifference (ProductID, '2000-01-01', GETDATE()) AS CostVariance
FROM Production.Product;
GO
 
--QUERY 2
SELECT ProductID, [Name] AS ProductName, 
	dbo.ProductCostDifference (ProductID, '2000-01-01', GETDATE()) AS CostVariance
FROM Production.Product
WHERE dbo.ProductCostDifference (ProductID, '2000-01-01', GETDATE()) IS NOT NULL;
GO
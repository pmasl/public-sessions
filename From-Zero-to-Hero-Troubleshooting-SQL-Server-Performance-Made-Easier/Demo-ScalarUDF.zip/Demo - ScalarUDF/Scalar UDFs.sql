------------------------------------------------------------------------------------------
-- Demo Scalar UDFs
------------------------------------------------------------------------------------------

-- Check SSMS option "Actual Execution Plan"

USE AdventureWorks2016CTP3;
GO

-- Create UDF
CREATE FUNCTION ufn_CategorizePrice(@Price money)
RETURNS NVARCHAR(50)
AS
BEGIN
	DECLARE @PriceCategory NVARCHAR(50)

	IF @Price < 100 SELECT @PriceCategory = 'Cheap'
	IF @Price BETWEEN 101 and 500 SELECT @PriceCategory =  'Mid Price'
	IF @Price BETWEEN 501 and 1000 SELECT @PriceCategory =  'Expensive'
	IF @Price > 1001 SELECT @PriceCategory =  'Unaffordable'
	RETURN @PriceCategory 
END
GO

------------------------------------------------------------------------------------------
-- Optional
-- Create and watch live data from below xEvent trace
DROP EVENT SESSION [ScalarUDFs] ON SERVER 
GO

CREATE EVENT SESSION [ScalarUDFs] ON SERVER 
ADD EVENT sqlserver.module_end(
    ACTION(sqlserver.database_name,sqlserver.sql_text)
    WHERE ([sqlserver].[equal_i_sql_ansi_string]([object_type],'FN') AND [sqlserver].[database_name]=N'AdventureWorks2016CTP3'))
ADD TARGET package0.histogram(SET filtering_event_name=N'sqlserver.module_end',source=N'object_name',source_type=(0))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO
------------------------------------------------------------------------------------------

DBCC DROPCLEANBUFFERS
GO
-- Now execute a query that references it
SELECT dbo.ufn_CategorizePrice(UnitPrice), 
	SalesOrderID, SalesOrderDetailID, CarrierTrackingNumber, 
	OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount, 
	LineTotal, rowguid, ModifiedDate 
FROM Sales.SalesOrderDetail
GO

------------------------------------------------------------------------------------------
-- Stop and observe the trace
-- How many executions of the UDF?
-- Is this execution showing in the Execution Plan?
------------------------------------------------------------------------------------------




DBCC DROPCLEANBUFFERS
GO
-- Fix with inline
SELECT CASE WHEN UnitPrice < 100 THEN 'Cheap'
		WHEN UnitPrice BETWEEN 101 and 500 THEN 'Mid Price'
		WHEN UnitPrice BETWEEN 501 and 1000 THEN 'Expensive'
		WHEN UnitPrice > 1001 THEN 'Unaffordable' END, 
	SalesOrderID, SalesOrderDetailID, CarrierTrackingNumber, 
	OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount, 
	LineTotal, rowguid, ModifiedDate 
FROM Sales.SalesOrderDetail
GO



------------------------------------------------------------------------------------------
-- Demo 2 Scalar UDFs
------------------------------------------------------------------------------------------
USE AdventureWorks2012;
GO

-- Create UDF
CREATE FUNCTION dbo.ComputeNum(@i int)
RETURNS int
BEGIN
  RETURN @i * 2 + 50
END
GO

-- Execute statements below and verify results

-- Object accesses system data, system catalogs or virtual system tables, in the local instance of SQL Server?
SELECT OBJECTPROPERTYEX(OBJECT_id('dbo.ComputeNum'), 'SystemDataAccess')
-- Object accesses user data, user tables, in the local instance of SQL Server?
SELECT OBJECTPROPERTYEX(OBJECT_id('dbo.ComputeNum'), 'UserDataAccess')
-- The precision and determinism properties of the object can be verified by SQL Server?
SELECT OBJECTPROPERTYEX(OBJECT_id('dbo.ComputeNum'), 'IsSystemVerified')
GO


-- Even though the function itself does not do any data access, SQL Server thinks that it does.
-- Why?


-- ANSWER: To avoid deriving underlying schema properties in each execution, we simply mark 
-- the UDF as being able to access data, and play it safe.
-- And why is this important?


-- Create and populate next table
CREATE TABLE t1 (c1 int);
CREATE INDEX IX_t1 ON t1 (c1 ASC);
DECLARE @counter smallint;
SET @counter = 1;
WHILE @counter < 250
	BEGIN
		INSERT INTO t1
		SELECT @counter
		SET @counter += 1
	END;
GO


-- Execute statements below and verify the query plan
UPDATE t1 
SET c1 = c1 + 5 
WHERE dbo.ComputeNum(c1) > 50;
GO


-- What are we seeing?
-- A spool is being created (remember Halloween protection?)
-- Also note the amount of logical I/O in the spool (Worktable)
-- Could we avoid it?




-- Create same UDF with schema binding
DROP FUNCTION dbo.ComputeNum
GO
CREATE FUNCTION dbo.ComputeNum(@i int)
RETURNS int
WITH SCHEMABINDING
BEGIN
  RETURN @i * 2 + 50
END
GO


-- Execute statements below and verify results

-- Object accesses system data, system catalogs or virtual system tables, in the local instance of SQL Server?
SELECT OBJECTPROPERTYEX(OBJECT_id('dbo.ComputeNum'), 'SystemDataAccess')
-- Object accesses user data, user tables, in the local instance of SQL Server?
SELECT OBJECTPROPERTYEX(OBJECT_id('dbo.ComputeNum'), 'UserDataAccess')
-- The precision and determinism properties of the object can be verified by SQL Server?
SELECT OBJECTPROPERTYEX(OBJECT_id('dbo.ComputeNum'), 'IsSystemVerified')
GO


-- What changed?


-- ANSWER: Making the UDF schema-bound, as in the following example,�forces SQL Engine 
-- to analyze the body of the UDF and properly set these derived properties.

-- Execute statements below and verify the query plan
UPDATE t1 
SET c1 = c1 + 5 
WHERE dbo.ComputeNum(c1) > 50;
GO


-- What changed?


-- ANSWER: No more spooling takes place. 
-- What about performance?

-- Cleanup
DROP FUNCTION dbo.ufn_CategorizePrice
DROP FUNCTION dbo.ComputeNum
DROP TABLE t1
GO
USE AdventureWorks2016CTP3
GO

EXEC dbo.usp_test
GO

!!..\bin\sleep 1
GO
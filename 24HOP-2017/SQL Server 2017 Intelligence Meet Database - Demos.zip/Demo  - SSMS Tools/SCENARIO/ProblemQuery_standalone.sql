USE AdventureWorks2016CTP3
GO

SELECT sh.SalesOrderID AS [Order], nextorder_sh.SalesOrderID AS NextOrder,  
	SUM (nextorder_sd.LineTotal) - SUM (sd.LineTotal) AS Trend, 
	(SELECT AVG (TotalDue) FROM Sales.SalesOrderHeader AS sh3 WHERE sh3.CustomerID = nextorder_sh.CustomerID)
		AS acct_avg
FROM Sales.SalesOrderDetail AS sd
INNER JOIN Sales.SalesOrderHeader AS sh ON sd.SalesOrderID = sh.SalesOrderID
INNER JOIN Sales.SalesOrderHeader AS nextorder_sh ON sh.CustomerID = nextorder_sh.CustomerID 
	AND nextorder_sh.SalesOrderID = (
		SELECT TOP 1 sh2.SalesOrderID FROM Sales.SalesOrderHeader AS sh2
		WHERE sh2.CustomerID = nextorder_sh.CustomerID AND sh2.OrderDate > sh.OrderDate
		ORDER BY sh2.OrderDate
	)
INNER JOIN Sales.SalesOrderDetail AS nextorder_sd ON nextorder_sd.SalesOrderID = nextorder_sh.SalesOrderID
GROUP BY nextorder_sh.CustomerID, sh.SalesOrderID, nextorder_sh.SalesOrderID
OPTION (LOOP JOIN)
GO

!!..\bin\sleep 1
GO

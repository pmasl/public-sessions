IF NOT EXISTS (SELECT database_id FROM sys.databases (NOLOCK) WHERE [name] = N'ParallelTest')
CREATE DATABASE ParallelTest
GO
USE ParallelTest
GO
SET NOCOUNT ON;
IF NOT EXISTS (SELECT [object_id] FROM sys.objects (NOLOCK) WHERE [object_id] = OBJECT_ID(N'orders') AND [type] IN (N'U'))
CREATE TABLE orders (d_id INT, o_id INT, o_amount INT, o_description CHAR(2000)) 
GO
CREATE UNIQUE CLUSTERED INDEX test ON orders(d_id, o_id)
GO

IF (SELECT COUNT(*) FROM orders) < 800000
BEGIN
	TRUNCATE TABLE orders;

	DECLARE @i INT 
	SET @i = 1 
	WHILE @i <= 800000 
	BEGIN 
		INSERT INTO orders VALUES (@i % 8, @i, RAND() * 800000, REPLICATE('a', 2000)) 
		SET @i = @i + 1 
	END
END
GO

UPDATE STATISTICS orders WITH FULLSCAN 
GO 
CREATE TABLE #department (d_id INT) 
INSERT INTO #department VALUES(0) 
INSERT INTO #department VALUES(1) 
INSERT INTO #department VALUES(2) 
INSERT INTO #department VALUES(3) 
INSERT INTO #department VALUES(4) 
INSERT INTO #department VALUES(5) 
INSERT INTO #department VALUES(6) 
INSERT INTO #department VALUES(7) 
GO 

--Clear the current stats to start afresh
DBCC SQLPERF("sys.dm_os_wait_stats" , CLEAR)
GO

--Verify that the waitstats have been cleared
SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

DECLARE @order_amount INT 
SELECT @order_amount = MAX(o_amount) 
FROM orders o INNER JOIN #department d ON (o.d_id = d.d_id) 
GO 

SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

/*
Track waits:

*/ 

-- Now skew data
TRUNCATE TABLE #department 
INSERT INTO #department VALUES (1) 
INSERT INTO #department VALUES (3) 
INSERT INTO #department VALUES (5)
INSERT INTO #department VALUES (7) 

--Clear the current stats to start afresh
DBCC SQLPERF("sys.dm_os_wait_stats" , CLEAR)
GO

--Verify that the waitstats have been cleared
SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

DECLARE @order_amount INT 
SELECT @order_amount = MAX(o_amount) 
FROM orders o INNER JOIN #department d ON (o.d_id = d.d_id) 
GO 

SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

/*
Track waits:

*/ 
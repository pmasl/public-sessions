--Clear the current stats to start afresh
DBCC SQLPERF("sys.dm_os_wait_stats" , CLEAR)
GO

--Verify that the waitstats have been cleared
SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

SELECT *
FROM Sales.SalesOrderDetailBulk SOD
INNER JOIN Production.Product P ON SOD.ProductID = P.ProductID
WHERE SalesOrderDetailID > 10
ORDER BY Style
go

SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

SELECT * FROM sys.dm_exec_session_wait_stats WHERE session_id = @@SPID
GO

/*
Track waits:

*/

--Clear the current stats to start afresh
DBCC SQLPERF("sys.dm_os_wait_stats" , CLEAR)
GO

--Verify that the waitstats have been cleared
SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

SELECT *
FROM Sales.SalesOrderDetailBulk SOD
INNER JOIN Production.Product P ON SOD.ProductID = P.ProductID
WHERE SalesOrderDetailID > 10
ORDER BY Style
OPTION(MAXDOP 4)
go

SELECT * FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'CX%'
GO

SELECT * FROM sys.dm_exec_session_wait_stats WHERE session_id = @@SPID
GO

/*
Track waits:

*/